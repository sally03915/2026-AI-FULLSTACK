/*******
* routes-user.js
----------------------------
* 사용자관련 API라우터
*/
const express = require('express');
const {    createUser,  getAllUsers,  updateUserNickname
        ,  deleteUser} = require('../models/users');
const router = express.Router();   

//회원가입
/**
 * @swagger
 * /user/register:
 *   post:
 *     summary: 회원가입
 *     description: 새로운 사용자를 등록합니다.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email: { type: string }
 *               password: { type: string }
 *               nickname: { type: string }
 *               mobile: { type: string }
 *               mbtiTypeId: { type: integer }
 *               ufile: { type: string }
 *     responses:
 *       200:
 *         description: 로그인 성공 (테스트용)
 */
router.post('/register'      , async(req, res)=>{
    try{
        const {email, password, nickname, mobile, mbtiTypeId, ufile} = req.body;
        await  createUser(email, password, nickname, mobile, mbtiTypeId, ufile);  
        res.status(201).json({message:'회원가입 성공'}); //200 ok  , 201 created
    }catch(err){
        console.error('Register Error' , err);
        res.status(500).json({message:'회원가입 실패'});
    }
});

//로그인
/**
 * @swagger
 * /user/login:
 *   post:
 *     summary: 로그인 (테스트용)
 *     description: 이메일과 비밀번호를 받아서 단순 응답을 반환합니다.. (Passport 미적용)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email: { type: string }
 *               passord: { type: string }
 *     responses:
 *       200:
 *         description: 로그인 성공 (테스트용)
 */
router.post('/login'         , async(req, res)=>{
    const {email , password} = req.body;
    // 실제 검증은 models/users.js의 verfiyUser 사용가능
    res.json({message:'로그인 테스트 성공' , email, password});
});
 
//로그아웃
/**
 * @swagger
 * /user/logout:
 *   post:
 *     summary: 로그아웃 (테스트용)
 *     description: 세션/쿠키 없이 단순 응답 반환
 *     responses:
 *       200:
 *         description: 로그아웃 성공
 */
router.post('/logout'        , async(req, res)=>{
    res.json({message:'로그아웃 성공(테스트용)'});
}); 

//전체 사용자 조회
/**
 * @swagger
 * /user/:
 *   get:
 *     summary: 전체 사용자 조회
 *     description: 모든 사용자의 목록을 반환합니다. (인증 미적용)
 *     responses:
 *       200:
 *         description: 사용자 목록 반환
 */
router.get('/'               , async(req, res)=>{
    try{ 
        const users = await getAllUsers();
        res.json(users);
    }catch(err){
        console.error('GetAllUsers Error' , err);
        res.status(500).json({message:'사용자 조회 실패'});
    }
});

//닉네임 수정
/**
 * @swagger
 * /user/{id}/nickname:
 *   patch:
 *     summary: 닉네임 수정
 *     description: 특정 사용자의 닉네임을 수정합니다. (인증 미적용)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nickname: { type: string }
 *     responses:
 *       200:
 *         description: 닉네임 수정 완료
 */
router.patch('/:id/nickname' , async(req, res)=>{
    try{ 
        const {nickname} = req.body;
        await  updateUserNickname( req.params.id  , nickname);
        res.json({message : '닉네임 수정 완료'});
    }catch(err){
        console.error('UpdateUserNickname Error' , err);
        res.status(500).json({message:'닉네임 수정 실패'});
    }
});

//사용자 삭제  
/**
 * @swagger
 * /user/{id}:
 *   delete:
 *     summary: 사용자 삭제
 *     description: 특정 사용자를 삭제합니다. (인증 미적용)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: 사용자 삭제 완료
 */
router.delete('/:id'         , async(req, res)=>{
    try{  
        await  deleteUser( req.params.id);
        res.json({message : '사용자 삭제 완료'});
    }catch(err){
        console.error('DeleteUser Error' , err);
        res.status(500).json({message:'사용자 삭제 실패'});
    }
});
module.exports = router;